"use strict";

	/* Group Assignment */
    /* Author: Tyler Plogger, Peter Bergstorm, Matt Pilgrim */
    /* Date: 11/3/21 */
    /* Filename: mc_order.js */
	
